import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import client from '../../api/client';
import { DataGrid } from '@mui/x-data-grid';
import { Button } from '@mui/material';

export default function AdminPage() {
  const qc = useQueryClient();

  const { data = [] } = useQuery({
    queryKey: ['movies'],
    queryFn: async () => (await client.get('/movies')).data
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => client.delete(`/movies/${id}`),
    onSuccess: () => qc.invalidateQueries(['movies'])
  });

  const columns = [
    { field: 'id', headerName: 'ID', width: 90 },
    { field: 'title', headerName: 'Title', flex: 1 },
    {
      field: 'actions',
      renderCell: (params) => (
        <Button onClick={() => deleteMutation.mutate(params.row.id)}>
          Delete
        </Button>
      )
    }
  ];

  return (
    <div style={{ height: 500 }}>
      <DataGrid rows={data} columns={columns} />
    </div>
  );
}