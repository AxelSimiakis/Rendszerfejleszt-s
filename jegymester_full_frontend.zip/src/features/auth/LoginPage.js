import { useForm } from 'react-hook-form';
import { TextField, Button, Container } from '@mui/material';
import { useAuth } from '../../context/AuthContext';

export default function LoginPage() {
  const { login } = useAuth();
  const { register, handleSubmit } = useForm();

  const onSubmit = (data) => login(data.email, data.password);

  return (
    <Container maxWidth="sm">
      <h2>Login</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <TextField label="Email" fullWidth {...register('email')} />
        <TextField label="Password" type="password" fullWidth {...register('password')} />
        <Button type="submit" variant="contained">Login</Button>
      </form>
    </Container>
  );
}