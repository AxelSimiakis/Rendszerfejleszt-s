import { useParams } from 'react-router-dom';
import { useSeats, useReserveSeats } from './useSeats';
import { useState } from 'react';
import { Button } from '@mui/material';

const ROWS = 'ABCDEFGH'.split('');
const COLS = 10;

export default function SeatPage() {
  const { screeningId } = useParams();
  const { data: seats = [], isLoading } = useSeats(screeningId);
  const reserve = useReserveSeats();

  const [selected, setSelected] = useState([]);

  if (isLoading) return <div>Loading...</div>;

  const seatMap = {};
  seats.forEach((s, i) => {
    const row = ROWS[Math.floor(i / COLS)];
    const col = (i % COLS) + 1;
    if (!seatMap[row]) seatMap[row] = [];
    seatMap[row].push({ ...s, label: `${row}${col}` });
  });

  return (
    <div style={{ textAlign: 'center' }}>
      <h2>🎬 Seat Picker</h2>

      <div style={{ marginBottom: 20, background: '#ccc', padding: 10 }}>
        SCREEN
      </div>

      {Object.keys(seatMap).map(row => (
        <div key={row}>
          {seatMap[row].map(seat => (
            <span
              key={seat.id}
              onClick={() => !seat.reserved &&
                setSelected(prev =>
                  prev.includes(seat.id)
                    ? prev.filter(x => x !== seat.id)
                    : [...prev, seat.id]
                )
              }
              style={{
                display: 'inline-block',
                width: 30,
                height: 30,
                margin: 3,
                background: seat.reserved
                  ? 'red'
                  : selected.includes(seat.id)
                  ? 'green'
                  : 'gray'
              }}
            />
          ))}
        </div>
      ))}

      <Button onClick={() =>
        reserve.mutate({ screeningId, seats: selected })
      }>
        Foglalás
      </Button>
    </div>
  );
}