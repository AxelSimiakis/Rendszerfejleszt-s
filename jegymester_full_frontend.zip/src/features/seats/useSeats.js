import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import client from '../../api/client';

export const useSeats = (screeningId) =>
  useQuery({
    queryKey: ['seats', screeningId],
    queryFn: async () => (await client.get(`/seats/${screeningId}`)).data
  });

export const useReserveSeats = () => {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: ({ screeningId, seats }) =>
      client.post('/tickets/reserve', { screeningId, seats }),

    onSuccess: (_, vars) => {
      qc.invalidateQueries(['seats', vars.screeningId]);
    }
  });
};