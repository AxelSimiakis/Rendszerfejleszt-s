from app.extensions import db
from app.models.ticket import Ticket
from sqlalchemy import select
from .schemas import TicketResponseSchema
import traceback

class TicketService:
    @staticmethod
    def get_all_tickets():
        try:
            tickets = db.session.execute(select(Ticket)).scalars().all()
            return TicketResponseSchema(many=True).dump(tickets)
        except Exception as ex:
            print(f"Hiba a jegyek lekerdezesenel: {ex}")
            return []

    @staticmethod
    def create_ticket(data):
        try:
            ticket = Ticket(**data)
            db.session.add(ticket)
            db.session.commit()
            return True, TicketResponseSchema().dump(ticket)
        except Exception as ex:
            db.session.rollback()
            print("HIBA A JEGY MENTESENEL:")
            traceback.print_exc()
            return False, str(ex)

    @staticmethod
    def delete_ticket(ticket_id):
        try:
            ticket = db.session.get(Ticket, ticket_id)
            if not ticket:
                return False, "Jegy nem talalhato"
            db.session.delete(ticket)
            db.session.commit()
            return True, "Jegy sikeresen torolve"
        except Exception as ex:
            db.session.rollback()
            return False, str(ex)